<button class="admin-menu-toggle" aria-label="Abrir menu do administrador">☰</button>

<header class="admin-header">
    <h1>Admin DRTDRFT</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="eventos.php">Eventos</a>
        <a href="usuarios.php">Usuários</a>
        <a href="ver_inscricoes.php">Inscrições</a>
        <a href="validar_key.php">Validar Key</a>
        <a href="patrocinadores.php">Patrocinadores</a>
        <a href="logs.php">Logs</a>
        <a href="../logout.php" class="btn-logout">Sair</a>
    </nav>
</header>