<footer>
        <div class="container">
            <div class="social-links">
                <a href="https://www.instagram.com/drtdrft" target="_blank" rel="noopener noreferrer" title="Siga-nos no Instagram @drtdrft">
                    <img src="assets/img/instagram_logo.png" alt="Instagram DRTDRFT" class="social-icon">
                </a>
            </div>
            <p>&copy; <?php echo date('Y'); ?> DRTDRFT CONTROL. Todos os direitos reservados.</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>

</body>
</html>