document.addEventListener('DOMContentLoaded', function() {
    // Lógica para o menu principal do site
    const menuToggle = document.querySelector('.menu-toggle');
    const mainNav = document.querySelector('header.main-header nav');
    
    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', function() {
            // Adiciona ou remove a classe 'is-active'
            const isActive = mainNav.classList.toggle('is-active');
            
            // Muda o ícone do botão: se o menu está ativo, mostra 'X', senão, mostra '☰'
            if (isActive) {
                menuToggle.innerHTML = '&times;'; // &times; é o caractere 'X'
                menuToggle.setAttribute('aria-label', 'Fechar menu');
            } else {
                menuToggle.innerHTML = '☰';
                menuToggle.setAttribute('aria-label', 'Abrir menu');
            }
        });
    }

    // Lógica para o menu do painel de administração (continua a mesma)
    const adminMenuToggle = document.querySelector('.admin-menu-toggle');
    const adminContainer = document.querySelector('.admin-container');

    if (adminMenuToggle && adminContainer) {
        adminMenuToggle.addEventListener('click', function() {
            adminContainer.classList.toggle('sidebar-is-active');
        });
    }
});