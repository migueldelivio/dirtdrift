<?php echo "Página teste.php funcionando!"; ?>
